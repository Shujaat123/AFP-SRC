%% AFP-SRC: Identification of Antifreeze Proteins Using Sparse Representation Classifier
% Written by: Shujaat Khan

clc
clear all
close all

%% loading protein sequence dataset (pre-processed 840 features)
data_dir = ['data\'];
train_file = ['train1.csv'];
test_file = ['test1.csv'];
train_db = [data_dir,train_file];
test_db = [data_dir,test_file];

X_train = csvread(train_db,1,1);
X_test = csvread(test_db,1,1);

%%
T = readtable(train_db,'ReadVariableNames',false);
% T = table2cell(T(2:end,1));
T = table2cell(T(1:end,1));
for i = 1:length(T)
    if (strcmp(T{i},'AFP'))
        Y_train(i) = 1;
    elseif (strcmp(T{i},'NON_AFP'))
        Y_train(i) = 2;
    end
end

T = readtable(test_db,'ReadVariableNames',false);
% T = table2cell(T(2:end,1));
T = table2cell(T(1:end,1));
for i = 1:length(T)
    if (strcmp(T{i},'AFP'))
        Y_test(i) = 1;
    elseif (strcmp(T{i},'NON_AFP'))
        Y_test(i) = 2;
    end
end

%% cross validation by randomly selection training and test datasets
Y_pos = [Y_train(find(Y_train==1)), Y_test(find(Y_test==1))];
Y_neg = [Y_train(find(Y_train==2)), Y_test(find(Y_test==2))];
X_pos = [X_train(find(Y_train==1),:);X_test(find(Y_test==1),:)];
X_neg = [X_train(find(Y_train==2),:);X_test(find(Y_test==2),:)];

runs = [1:10];  % number of Monte Carlos simulations

for param_config = 1:4
    %% SRC
    % epsilon - scalar, constraint relaxation parameter
    %
    % lbtol - The log barrier algorithm terminates when the duality gap <= lbtol.
    %         Also, the number of log barrier iterations is completely
    %         determined by lbtol.
    %         Default = 1e-3.
    %
    % mu - Factor by which to increase the barrier constant at each iteration.
    %      Default = 10.
    if(param_config==1)
        mu = 10;
        noise_std = 1;
        epsilon = 0.05;
        lbtol = 1e-3;
    elseif(param_config==2)
        mu = 10;
        noise_std = 1;
        epsilon = 0.05;
        lbtol = 1e-2;
    elseif(param_config==3)
        mu = 10;
        noise_std = 1;
        epsilon = 0.5;
        lbtol = 1e-3;
    elseif(param_config==4)
        mu = 10;
        noise_std = 1;
        epsilon = 0.5;
        lbtol = 1e-2;
    elseif(param_config==5)
        mu = 10;
        noise_std = 5;
        epsilon = 0.05;
        lbtol = 1e-3;
    elseif(param_config==6)
        mu = 10;
        noise_std = 5;
        epsilon = 0.05;
        lbtol = 1e-2;
    elseif(param_config==7)
        mu = 10;
        noise_std = 5;
        epsilon = 0.5;
        lbtol = 1e-3;
    elseif(param_config==8)
        mu = 10;
        noise_std = 5;
        epsilon = 0.5;
        lbtol = 1e-2;
    end
    
    for run = runs
        randomized_pos_index = randperm(size(X_pos,1));
        randomized_neg_index = randperm(size(X_neg,1));

        % update train and test sets
        Y_train = [Y_pos(:,randomized_pos_index(1:300)), Y_neg(:,randomized_neg_index(1:300))];
%         Y_test = [Y_pos(:,randomized_pos_index(301:end)), Y_neg(:,randomized_neg_index(301:end))];
        Y_test = Y_train;

        X_train = [X_pos(randomized_pos_index(1:300),:);X_neg(randomized_neg_index(1:300),:)];
%         X_test = [X_pos(randomized_pos_index(301:end),:);X_neg(randomized_neg_index(301:end),:)];
        X_test = X_train;

        %% Modeling parameter
        classes=2;
        train=300;
        n=classes*train;

        [V,D] = eig(cov(X_train));
        [D, Fr] = sort(diag(D),'descend');
        Results_delta_rule =[];
        Results_max_rule =[];
        Results_max_norm_rule =[];

        features = [10:10:100 150:25:250 300:100:600];
        % check if previous results are available
        if(isfile(['Results_Train\Results_param_config',int2str(param_config),'_run',int2str(run),'.mat']))
            load(['Results_Train\Results_param_config',int2str(param_config),'_run',int2str(run),'.mat'])
        end
        X_train_original=X_train;
        for feature_len = size(Results_delta_rule,1)+1:numel(features)
        num_features = features(feature_len);
        X_train = X_train_original + noise_std*randn(size(X_train_original));
        
        A=X_train*V(:,Fr(1:num_features));
        A = A';
        % X_train = A;

        test_1 = X_test*V(:,Fr(1:num_features));
        test_1 = test_1';

        class_test = Y_test;
        %% SRC
        %%Testing%%%%%%%%%%
        count_delta_rule=0;
        afp_count_delta_rule=0;
        non_afp_count_delta_rule=0;

        count_max_rule=0;
        afp_count_max_rule=0;
        non_afp_count_max_rule=0;

        count_max_norm_rule=0;
        afp_count_max_norm_rule=0;
        non_afp_count_max_norm_rule=0;

        total_afps = numel(find(class_test==1));
        total_non_afps = numel(find(class_test==2));
        l1_recon_time = 0;
        for i=1:size(test_1,2)
            y=test_1(:,i);
        	tic()
            x0=A\y;         % initial L2 solution
            xp=l1qc_logbarrier(x0 ,A ,[] ,y ,epsilon, lbtol, mu); % findc L1 solution
            l1_recon_time = l1_recon_time + toc();

        %% Delta rule for reconstruction
        delta=zeros(n,1);
        score_delta_rule=zeros(classes,1);
        k=1;
        for u=1:train:train*classes
            delta(u:u+train-1,1)=xp(u:u+train-1,1);

            yp=A*delta;
            r_y=sum((y-yp).^2).^0.5;
            score_delta_rule(k,1)=r_y;
            delta=zeros(n,1);
            k=k+1;     
        end

        %%%Decision rule
        [value,class]=min(score_delta_rule);
        if (class_test(i)==1)
            if class==class_test(i)
                count_delta_rule=count_delta_rule+1;
                afp_count_delta_rule = afp_count_delta_rule+1;
            end
        elseif (class_test(i)==2)
            if class==class_test(i)
                count_delta_rule=count_delta_rule+1;
                non_afp_count_delta_rule = non_afp_count_delta_rule+1;
            end
        end

        %% MAX rule for decision
        [val, pos] = max(xp);
        if (class_test(i)==1)
            if pos<=train
                count_max_rule=count_max_rule+1;
                afp_count_max_rule = afp_count_max_rule+1;
            end
        elseif (class_test(i)==2)
            if pos>train
                count_max_rule=count_max_rule+1;
                non_afp_count_max_rule = non_afp_count_max_rule+1;
            end
        end

        %% Max-norm rule for score
        k=1;
        score_max_norm_rule=zeros(classes,1);
        for u=1:train:train*classes
            score_max_norm_rule(k,1)=norm(xp(u:u+train-1,1));
            k=k+1;     
        end

        % Decision rule
        [value,class]=max(score_max_norm_rule);
        if (class_test(i)==1)
            if class==class_test(i)
                count_max_norm_rule=count_max_norm_rule+1;
                afp_count_max_norm_rule = afp_count_max_norm_rule+1;
            end
        elseif (class_test(i)==2)
            if class==class_test(i)
                count_max_norm_rule=count_max_norm_rule+1;
                non_afp_count_max_norm_rule = non_afp_count_max_norm_rule+1;
            end
        end
        %% show stats
        [count_delta_rule i;count_max_rule i;count_max_norm_rule i]    
        [afp_count_delta_rule/total_afps non_afp_count_delta_rule/total_non_afps count_delta_rule/i; ...
            afp_count_max_rule/total_afps non_afp_count_max_rule/total_non_afps count_max_rule/i; ...
            afp_count_max_norm_rule/total_afps non_afp_count_max_norm_rule/total_non_afps count_max_norm_rule/i]


        end
             %% record stats
        Results_delta_rule(feature_len,:)=[afp_count_delta_rule/total_afps non_afp_count_delta_rule/total_non_afps count_delta_rule/i 0.01*l1_recon_time/size(test_1,2)]*100;
        Results_max_rule(feature_len,:)=[afp_count_max_rule/total_afps non_afp_count_max_rule/total_non_afps count_max_rule/i 0.01*l1_recon_time/size(test_1,2)]*100;
        Results_max_norm_rule(feature_len,:)=[afp_count_max_norm_rule/total_afps non_afp_count_max_norm_rule/total_non_afps count_max_norm_rule/i 0.01*l1_recon_time/size(test_1,2)]*100;

        save(['Results_Train\Results_param_config',int2str(param_config),'_run',int2str(run),'.mat'], 'Results_delta_rule', 'Results_max_rule', 'Results_max_norm_rule', 'features', 'total_afps', 'total_non_afps');
        end
    end
end